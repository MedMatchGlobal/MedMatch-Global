import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(req: NextRequest) {
  const { drug, dosage, country } = await req.json();

  const prompt = `You are a pharmacist. The user is looking for the international equivalent of a medication.
Original drug: ${drug}, Dosage: ${dosage}. What is the equivalent medication in ${country}? Provide a short summary.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
  });

  const summary = response.choices[0]?.message?.content || 'No match found.';
  return NextResponse.json({ summary });
}
